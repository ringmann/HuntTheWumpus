/**
 * File: TestGraph.java
 * Author: Rosie Ingmann
 * Date: 05/12/2021
 *CS231
 */	
//This class creates a graph and tests rhe shortest path algoritm on the graph

import java.util.ArrayList;

public class TestGraph{

	public static void main(String[] args) {
		Vertex v1= new Vertex(5,5);
		Vertex v2= new Vertex(6,1);
		Vertex v3= new Vertex(3,3);
		Vertex v4= new Vertex(7,2);
		Vertex v5= new Vertex(1,8);
		Vertex v6= new Vertex(4,0);
		Vertex v7= new Vertex(0,0);
		Vertex v8= new Vertex(2,6);
		Vertex v9= new Vertex(8,8);
		Vertex v10= new Vertex(10,5);
		Graph g= new Graph();
		g.addBiEdge(v1, v10);
		g.addBiEdge(v1, v5);
		g.addBiEdge(v1, v6);
		g.addBiEdge(v2, v8);
		g.addBiEdge(v2, v6);
		g.addBiEdge(v3, v8);
		g.addBiEdge(v3, v7);
		g.addBiEdge(v4, v9);
		g.addBiEdge(v4, v10);
		g.addBiEdge(v5, v9);
		g.addBiEdge(v5, v8);
		g.addBiEdge(v6, v7);

		ArrayList<Vertex> set = g.getVertices();

		System.out.println("Before shortestPath");
		for( Vertex v: set ) {
			//System.out.println( v.getName() );
	    	System.out.println( v );
		}
	

		// run shortest path from node (0, 0)
		g.shortestPath( v1 );


		// print out after shortest path
		System.out.println("\nAfter shortestPath");
		for( Vertex v: set ) {
	    	System.out.println( v );
		}

		// run shortest path from node (0, 0)
		g.shortestPath( v8 );


		// print out after shortest path
		System.out.println("\nAfter shortestPath");
		for( Vertex v: set ) {
	    	System.out.println( v );
		}

	}
}




