/**
 * File: Landscape.java
 * Author: Rosie Ingmann
 * Date: 05/12/2021
 *CS231
 */	
//This class represents a Landscape in a game of HuntTheWumpus

import java.util.ArrayList;
import java.awt.Graphics;



public class Landscape{

	//fields width and height represent the size of the landscape
	//field vertices is the list of vertices within the landscape
	//there are fields for a hunter and wumpus, and also fields indicating whether or not to draw them
	private int width;
	private int height;
	private Hunter hunter;
	private Wumpus wumpus;
	private ArrayList<Vertex> vertices;
	private boolean drawWumpus;
	private boolean drawHunter;

	//constructor for landscape, takes in w and h paramters for setting width and height
	public Landscape(int w, int h){
		this.width=w;
		this.height=h;
		this.vertices=new ArrayList<Vertex>();
		this.drawWumpus=false;
		this.drawHunter=true;

	}

	//returns a list of the vertices in the landscape
	public ArrayList<Vertex> getVertices(){
		return this.vertices;
	}

	//returns the height if the landscape
	public int getHeight(){
		return this.height;
	}

	//returns the width of the landscape
	public int getWidth(){
		return this.width;
	}

	//sets the hunter field
	public void setHunter(Hunter h){
		this.hunter=h;
	}

	//sets the wumpus field
	public void setWumpus(Wumpus w){
		this.wumpus=w;
	}

	//sets whether to draw wumpus or not
	public void setDrawWumpus(boolean draw){
		this.drawWumpus=draw;
	}

	//returns whether to draw wumpus or not
	public boolean getDrawWumpus(){
		return this.drawWumpus;
	}

	//sets whether to draw hunter or not
	public void setDrawHunter(boolean draw){
		this.drawHunter=draw;
	}

	//returns whether to draw hunter or not
	public boolean getDrawHunter(){
		return this.drawHunter;
	}

	//adds a vertex to the landscape
	public void addBackgroundAgent(Vertex v){
		this.vertices.add(v);
	}

	//draws each vertex in the landscape as well as the hunter and wumpus if needed
	public void draw(Graphics g, int scale){
		for(Vertex vertex: vertices){
			vertex.draw(g, scale);
		}
		if (this.drawHunter==true){
			hunter.draw(g, scale);
		}
		if (this.drawWumpus==true){
			wumpus.draw(g, scale);

		}
	}
 	
 	public static void main(String[] args){
	 
	}











}