
/**
 * File: LinkedList.java
 * Author: Rosie Ingmann
 * Date: 03/22/2021
 *CS231
 */	
//This class represents the implementation of a LinkedList


import java.util.Iterator;    // defines the Iterator interface
import java.util.ArrayList;   
import java.util.Collections; // contains a shuffle function


public class LinkedList<T> implements Iterable<T>{

	// field size holds the current number of elements in the linked list
	//fields head and tail hold the nodes at the beginning and end of the linked list, respectively
	int size;
	Node head;
	Node tail;

	//contructor for linked list, initializes an empty linked list
	public LinkedList(){
		this.head=null;
		this.tail=null;
		this.size=0;
	}

	//clears the linked list, resetting it so that it is empty
	public void clear(){
		this.head=null;
		this.tail=null;
		this.size=0;
	}

	//returns the size of the linked list
	public int size(){
		return this.size;
	}

	//adds a new node at the front of the list that holds the imput parameter item
	public void addFirst(T item){
		Node added= new Node(item);
		if (this.head==null){
			this.head=added;
			this.tail=added;
		}
		else {
			added.next=this.head;
			this.head=added;
		}
		this.size ++;
	}

	//adds a new node at the back of the list that holds the imput parameter item
	public void addLast(T item){
		Node added= new Node(item);
		if(this.head==null){
			this.head=added;
			this.tail=added;
		}
		else{
			this.tail.next=added;
			this.tail=added;
		}
		this.size ++;

	}

	//adds a new node at a given index in the list that holds the imput parameter item
	public void add(int index, T item){
 		Node added = new Node(item);
 		Node current=this.head;
 		if(index==0){
 			this.addFirst(item);
 		}
 		else{
	 		for(int i=0; i<index; i++){
	 			if(i==index-1){
	 				added.next=current.next;
	 				current.next=added;
	 			}
	 			current=current.next;
	  		}
	  		this.size++;
  		}	
	}

	//removes the node at a given index in the list and returns its data
	public T remove (int index){
		Node current=this.head;
		T item=null;
 		if(index==0){
 			this.head=this.head.next;
		}
		for(int i=0; i<index; i++){
			if(i==index-1){
				item=current.next.t;
 				current.next=current.next.next;
 			}
 			current=current.next;
		}
		this.size --;
		return item;
	}

	//utilizes the iterator subclass for iterating through the linked list
	public Iterator <T> iterator(){
		return new LLIterator( this.head );
	}

	//returns an arraylist version of the linked list
	public ArrayList<T> toArrayList(){
 		ArrayList<T> newList= new ArrayList<T>();
 		for (T t: this) {
			newList.add(t);
 		}
 		return newList;
	}

	//returns an arrayList holding the data of the linked list in a shuffled order
	public ArrayList<T> toShuffledList(){
		ArrayList<T> newList= this.toArrayList();
		Collections.shuffle(newList);
		return newList;
	}

	//subclass node, each element of our linked list is a node
	private class Node{

		//initializing fields next and t
		//next holds the node that is the successor of this node
		//t holds the data stored within the node
		private Node next;
		private T t;

		//constructor for a node, sets the paramter item of type t to the variable t
		public Node(T item){
			next=null;
			t=item;
		}

		//returns the data stored within the node
		public T getThing(){
			return t;
		}

		//sets the value of next to an input Node n
		public void setNext(Node n){
			next= n;
		}

		//returns the node in the next position
		public Node getNext(){
			return next;
		}

	}

	//iterator subclass helps us create an iterator method in the class
	private class LLIterator implements Iterator<T>{
		
		//field holding the current node that the iterator is at
		Node current;

		//constructs the iterator
		public LLIterator(Node head){
			current=head;
		}

		//checks whether therr is another node in the list
		public boolean hasNext(){
			if (current != null){
				return true;
			}
			else{
				return false;
			}
		}

		//returns the data in current and sets the current field to the next node 
		public T next(){
			T a=current.t;
			current=current.next;
			return (a);
		}

		//not necessary
		public void remove(){

		}
	}
}