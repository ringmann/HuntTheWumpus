/**
 * File: HuntTheWumpus.java
 * Author: Rosie Ingmann
 * Date: 05/12/2021
 *CS231
 */ 
//This class represents a game of HuntTheWumpus


import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.Graphics;
import java.awt.Dimension;
import java.awt.Color;
import java.awt.event.MouseEvent;
import java.awt.Point;

import javax.imageio.ImageIO;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.event.MouseInputAdapter;

import java.util.*;

//the main class
public class HuntTheWumpus{

	private JFrame win;
    private LandscapePanel canvas;    
    private Landscape scape; 
    private int scale;

    JLabel field;

	private enum PlayState { PLAY, STOP }
    private PlayState state;

    private Graph graph;
    private Hunter hunter;
    private Wumpus wumpus;
    private Vertex v1  ;
    private Vertex v2 ;
    private Vertex v3 ;
    private Vertex v4 ;
    private Vertex v5 ;
    private Vertex v6 ;
    private Vertex v7 ;
    private Vertex v8 ;
    private Vertex v9 ;
    private Vertex v10 ;
    private Vertex v11 ;
    private Vertex v12  ;
    private Vertex v13  ;
    private Vertex v14 ;
    private Vertex v15  ;
    private Vertex v16  ;
    private Vertex v17 ;
    private Vertex v18  ;
    private Vertex v19 ;
    private Vertex v20  ;
    private Vertex v21  ;
    private Vertex v22 ;
    private Vertex v23 ;
    private Vertex v24 ;
    private Vertex v25 ;

 

    //constructor for the game
    public HuntTheWumpus(){
    	this.state = PlayState.PLAY; 
    	this.scale = 64;  
        this.scape = new Landscape(scale*10,scale*7);
        //makes the grid of vertices
        v1 = new Vertex( 0, 0 );
        v2 = new Vertex( 1, 0 );
         v3 = new Vertex( 2, 0 );
         v4 = new Vertex( 3, 0 );
         v5 = new Vertex( 4, 0 );
         v6 = new Vertex( 0, 1 );
         v7 = new Vertex( 1, 1 );
         v8 = new Vertex( 2, 1 );
         v9 = new Vertex( 3, 1 );
         v10 = new Vertex( 4, 1 );
         v11 = new Vertex( 0, 2 );
         v12 = new Vertex( 1, 2 );
         v13 = new Vertex( 2, 2 );
         v14 = new Vertex( 3, 2 );
         v15 = new Vertex( 4, 2 );
         v16 = new Vertex( 0, 3 );
         v17 = new Vertex( 1, 3 );
         v18 = new Vertex( 2, 3 );
         v19 = new Vertex( 3, 3 );
         v20 = new Vertex( 4, 3 );
         v21 = new Vertex( 0, 4 );
         v22 = new Vertex( 1, 4 );
         v23 = new Vertex( 2, 4 );
         v24 = new Vertex( 3, 4 );
         v25 = new Vertex( 4, 4 );
        ArrayList<Vertex> vertices= new ArrayList<Vertex>(Arrays.asList(v1 ,v2 ,v3 ,v4 ,v5 ,v6 ,v7 ,v8 ,v9 ,v10 ,v11 ,v12 ,v13 ,v14 ,v15, v16,
        	v17,v18, v19, v20, v21, v22, v23, v24, v25));
        for (int i=0; i< vertices.size(); i++){
        	vertices.get(i).setCost(100);
        	this.scape.addBackgroundAgent( vertices.get(i) );
        }
        this.graph= new Graph(vertices);
        //connects adjacent vertices
        for (int row=0; row<5; row++){
        	for (int col=0; col<5; col++){
        		ArrayList<Vertex> list= new ArrayList<Vertex>();
        		list.add(this.graph.get(row+1, col));
        		list.add(this.graph.get(row-1, col));
        		list.add(this.graph.get(row, col+1));
        		list.add(this.graph.get(row, col-1));
        		for (int i=0; i<list.size(); i++){
        			if (list.get(i) != null){
        				this.graph.addBiEdge(this.graph.get(row, col), list.get(i));
        			}
        		}
        	}
        }
        //creates a hunter and wumpus
        this.wumpus=new Wumpus(v20);
        this.hunter=new Hunter(v6);
        v6.setVisible(true);
        this.scape.setHunter(this.hunter);
        this.scape.setWumpus(this.wumpus);

 
        this.win = new JFrame("Hunt The Wumpus Game");
        win.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE);
        this.canvas = new LandscapePanel( this.scape.getWidth(), this.scape.getHeight() );
        this.win.add( this.canvas, BorderLayout.CENTER );
        this.win.pack();

        this.field = new JLabel("Hunt The Wumpus");
        JButton quit = new JButton("Quit");
        JButton replay = new JButton("Replay");
        JPanel panel = new JPanel( new FlowLayout(FlowLayout.RIGHT));
        panel.add( this.field );
        panel.add( quit );
        panel.add( replay);
        this.win.add( panel, BorderLayout.SOUTH);
        this.win.pack();

        Control control = new Control();
        this.win.addKeyListener(control);
        this.win.setFocusable(true);
        this.win.requestFocus();
        quit.addActionListener( control );
        replay.addActionListener( control);

        this.win.setVisible( true );


    }

    //control class which picks up on clicks and typing, does various tasks based on the action performed
    private class Control extends KeyAdapter implements ActionListener {

        //what to do if a key is typed
        public void keyTyped(KeyEvent e) {
            if( ("" + e.getKeyChar()).equalsIgnoreCase("q") ) {
                state = PlayState.STOP;
            }
            if( ("" + e.getKeyChar()).equalsIgnoreCase("w") ) {
            	Vertex above= HuntTheWumpus.this.graph.get(HuntTheWumpus.this.hunter.getPosition().getX(), HuntTheWumpus.this.hunter.getPosition().getY()-1);
            	if (above!=null){
                    if (HuntTheWumpus.this.hunter.getArmed()==true){
                        if (HuntTheWumpus.this.wumpus.getPosition().equals(above)){
                            HuntTheWumpus.this.wumpus.setAlive(false);
                            HuntTheWumpus.this.scape.setDrawWumpus(true);
                            field.setText("Woohoo! Wumpus killed by hunter");
                        }
                        else{
                            HuntTheWumpus.this.hunter.setAlive(false);
                            HuntTheWumpus.this.scape.setDrawWumpus(true);
                            field.setText( "Miss! The wumpus attacks");
                        }
                    }
                    else{
                        HuntTheWumpus.this.hunter.setPosition(above);
                        above.setVisible(true);
                        HuntTheWumpus.this.graph.shortestPath(wumpus.getPosition());
                    }
            	}
            }
            if( ("" + e.getKeyChar()).equalsIgnoreCase("s") ) {
            	//check if hunter has a neighbor above
            	Vertex below= HuntTheWumpus.this.graph.get(HuntTheWumpus.this.hunter.getPosition().getX(), HuntTheWumpus.this.hunter.getPosition().getY()+1);
            	if (below!=null){
            		if (HuntTheWumpus.this.hunter.getArmed()==true){
                        if (HuntTheWumpus.this.wumpus.getPosition().equals(below)){
                            HuntTheWumpus.this.wumpus.setAlive(false);
                            HuntTheWumpus.this.scape.setDrawWumpus(true);
                            field.setText("Woohoo! Wumpus killed by hunter");
                        }
                        else{
                            HuntTheWumpus.this.hunter.setAlive(false);
                            HuntTheWumpus.this.scape.setDrawWumpus(true);
                            field.setText( "Miss! The wumpus attacks");
                        }
                    }
                    else{
                        HuntTheWumpus.this.hunter.setPosition(below);
                        below.setVisible(true);
                        HuntTheWumpus.this.graph.shortestPath(wumpus.getPosition());
                    }
            	}
            }
            if( ("" + e.getKeyChar()).equalsIgnoreCase("d") ) {
            	//check if hunter has a neighbor above
            	Vertex right= HuntTheWumpus.this.graph.get(HuntTheWumpus.this.hunter.getPosition().getX()+1, HuntTheWumpus.this.hunter.getPosition().getY());
            	if (right!=null){
            		if (HuntTheWumpus.this.hunter.getArmed()==true){
                        if (HuntTheWumpus.this.wumpus.getPosition().equals(right)){
                            HuntTheWumpus.this.wumpus.setAlive(false);
                            HuntTheWumpus.this.scape.setDrawWumpus(true);
                            field.setText("Woohoo! Wumpus killed by hunter");
                        }
                        else{
                            HuntTheWumpus.this.hunter.setAlive(false);
                            HuntTheWumpus.this.scape.setDrawWumpus(true);
                            field.setText( "Miss! The wumpus attacks");
                        }
                    }
                    else{
                        HuntTheWumpus.this.hunter.setPosition(right);
                        right.setVisible(true);
                        HuntTheWumpus.this.graph.shortestPath(wumpus.getPosition());
                    }
            	}
            }
            if( ("" + e.getKeyChar()).equalsIgnoreCase("a") ) {
            	//check if hunter has a neighbor above
            	Vertex left= HuntTheWumpus.this.graph.get(HuntTheWumpus.this.hunter.getPosition().getX()-1, HuntTheWumpus.this.hunter.getPosition().getY());
            	if (left!=null){
            	   if (HuntTheWumpus.this.hunter.getArmed()==true){
                        if (HuntTheWumpus.this.wumpus.getPosition().equals(left)){
                            HuntTheWumpus.this.wumpus.setAlive(false);
                            HuntTheWumpus.this.scape.setDrawWumpus(true);
                            field.setText("Woohoo! Wumpus killed by hunter");
                         }
                        else{
                            HuntTheWumpus.this.hunter.setAlive(false);
                            HuntTheWumpus.this.scape.setDrawWumpus(true);
                            field.setText( "Miss! The wumpus attacks");
                        }
                    }
                    else{
                        HuntTheWumpus.this.hunter.setPosition(left);
                        left.setVisible(true);
                        HuntTheWumpus.this.graph.shortestPath(wumpus.getPosition());
                    }
            	}
            }
            if ( ("" + e.getKeyChar()).equalsIgnoreCase(" ") ){
            	if (HuntTheWumpus.this.hunter.getArmed()==false){
                    HuntTheWumpus.this.hunter.setArmed(true);
                    field.setText( "Hunter is armed" );
                }
                else{
                    HuntTheWumpus.this.hunter.setArmed(false); 
                    field.setText( "Hunter is no longer armed" );
                }
             }
             if (HuntTheWumpus.this.hunter.getPosition().equals(HuntTheWumpus.this.wumpus.getPosition())){
                HuntTheWumpus.this.hunter.setAlive(false);
                field.setText( "Oops! The wumpus has killed the hunter" );
             }
        }

        //what to do if a button is clicked
        public void actionPerformed(ActionEvent event) {
            // If the Quit button was pressed
            if( event.getActionCommand().equalsIgnoreCase("Quit") ) {
		        System.out.println("Quit button clicked");
                state = PlayState.STOP;
            }
            if( event.getActionCommand().equalsIgnoreCase("Replay") ) {
                System.out.println("Replay button clicked");
                HuntTheWumpus.this.hunter.setAlive(true);
                HuntTheWumpus.this.wumpus.setAlive(true);
                HuntTheWumpus.this.hunter.setPosition(HuntTheWumpus.this.v6);
                HuntTheWumpus.this.scape.setDrawWumpus(false);
                for (int i=0; i<25; i++){
                    HuntTheWumpus.this.scape.getVertices().get(i).setVisible(false);
                }
                HuntTheWumpus.this.v6.setVisible(true);
                HuntTheWumpus.this.hunter.setArmed(false);
                HuntTheWumpus.this.win.requestFocus();

                
            }
        }
    }  

    //landscape panel class
    private class LandscapePanel extends JPanel {
		
        /**
         * Creates the drawing canvas
         * @param height the height of the panel in pixels
         * @param width the width of the panel in pixels
         **/
        public LandscapePanel(int height, int width) {
            super();
            this.setPreferredSize( new Dimension( width, height ) );
            this.setBackground(Color.white);
        }

        /**
         * Method overridden from JComponent that is responsible for
         * drawing components on the screen.  The supplied Graphics
         * object is used to draw.
         * 
         * @param g		the Graphics object used for drawing
         */
        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            scape.draw( g, scale );
        }
    } // end class LandscapePanel

    //repaints the window
    public void repaint() {
    	this.win.repaint();
    }

    //disposes of the window
    public void dispose() {
	    this.win.dispose();
    }

    //main method which plays the game
    public static void main(String[] args) throws InterruptedException  {
    	HuntTheWumpus w = new HuntTheWumpus();
        while (w.state == PlayState.PLAY) {
            w.repaint();
            Thread.sleep(33);
        }
        System.out.println("Disposing window");
        w.dispose();
    }


}

