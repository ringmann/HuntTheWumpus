/**
 * File: Graph.java
 * Author: Rosie Ingmann
 * Date: 05/12/2021
 *CS231
 */	
//This class represents a Graph in a game of HuntTheWumpus

import java.util.PriorityQueue;
import java.util.ArrayList;
import java.util.Arrays;


public class Graph{

	private ArrayList<Vertex> vertices;

	//constructor initializes a graph given a list of vertices
	public Graph(ArrayList<Vertex> vertices){
		this.vertices=vertices;
	}

	//constructor initializes a graph without a list of vertices
	public Graph(){
		this.vertices=new ArrayList<Vertex>();
	}

	//returns the vertices in the graph
	public ArrayList<Vertex> getVertices(){
		return this.vertices;
	}

	//returns the number of vertices in the graph
	public int vertexCount(){
		return this.vertices.size();
	}

	//checks whether the graph contains a given vertex
	public boolean inGraph(Vertex query){
		return this.vertices.contains(query);
	}

	//returns the vertex at a given coordinate, or that there isn't one
	public Vertex get(int x, int y){
		for (int i=0; i< this.vertices.size(); i++){
			if (this.vertices.get(i).getX()==x && this.vertices.get(i).getY()==y){
				return this.vertices.get(i);
			}
		}
		return null;
	}

	//adds a unidiractional edge in the graph
	public void addUniEdge(Vertex v1, Vertex v2){
		if (!this.vertices.contains(v1)){
			this.vertices.add(v1);
		}
		if (!this.vertices.contains(v2)){
			this.vertices.add(v2);
		}
		v1.connect(v2);
	}

	//adds a bidirectional edge in the graph
	public void addBiEdge(Vertex v1, Vertex v2){
		if (!this.vertices.contains(v1)){
			this.vertices.add(v1);
		}
		if (!this.vertices.contains(v2)){
			this.vertices.add(v2);
		}
		v1.connect(v2);
		v2.connect(v1);
	}

	// calculates the cost of the shortest path between v0 and every other connected vertex in the graph
	public void shortestPath(Vertex v0){
		for (int i=0; i<this.vertexCount(); i++){
			this.vertices.get(i).setMarked(false);
			this.vertices.get(i).setCost(1e+7);
			this.vertices.get(i).setParent(null);
		}
		PriorityQueue pq= new PriorityQueue<>(new CompareCosts());
		v0.setCost(0);
		pq.add(v0);
		while (pq.size()!=0){
			Vertex v= (Vertex)pq.poll();
 			v.setMarked(true);
			for (int i=0; i<v.getNeighbors().size(); i++){
				Vertex w = v.getNeighbors().get(i);
				double dist = v.distance(w);
				if (w.getMarked()==false && (v.getCost()+dist<w.getCost())){
					w.setCost(v.getCost()+dist);
					w.setParent(v);
					pq.add(w);
				}
			}
		}
	}

	//main method for testing
	public static void main(String[] args) {
		Vertex v1= new Vertex(5,5, false);
		Vertex v2= new Vertex(6,1, false);
		Vertex v3= new Vertex(1,1, false);
		Vertex v4= new Vertex(7,3, false);
		Vertex v5= new Vertex(4,2, false);
		Vertex v6= new Vertex(8,8, false);
		v1.setNeighbors(new ArrayList<Vertex>(Arrays.asList(v4)));
		v2.setNeighbors(new ArrayList<Vertex>(Arrays.asList(v1,v6)));
		v3.setNeighbors(new ArrayList<Vertex>(Arrays.asList(v4, v5)));
		v4.setNeighbors(new ArrayList<Vertex>(Arrays.asList(v1, v2, v5)));
		v5.setNeighbors(new ArrayList<Vertex>(Arrays.asList(v2, v3)));
		v6.setNeighbors(new ArrayList<Vertex>(Arrays.asList(v3, v5)));
		ArrayList<Vertex> vertices= new ArrayList<Vertex>(Arrays.asList(v1,v2,v3,v4,v5,v6));
		Graph test = new Graph(vertices);
		System.out.println(test.vertices);
		test.shortestPath(v1);
		System.out.println(test.vertices);
		System.out.println(test.vertexCount());
		System.out.println(test.get(5,5));
		System.out.println(test.get(1,2));
		System.out.println(test.vertices);
		test.addUniEdge(v1, v6);
		System.out.println(test.vertices);

		
	}










}