/**
 * File: Hunter.java
 * Author: Rosie Ingmann
 * Date: 05/12/2021
 *CS231
 */	
//This class represents a Hunter in a game of HuntTheWumpus

import java.awt.Graphics;
import java.awt.Color;

public class Hunter{

	private Vertex position;
	private boolean armed;
	private boolean alive;

	//initializes the hunter as alive and not armed
	public Hunter(Vertex start){
		this.position=start;
		this.position.setVisible(true);
		this.armed=false;
		this.alive=true;
	}

	//returns the position vertex of the hunter
	public Vertex getPosition(){
		return this.position;
	}

	//sets the position vertex of the hunter
	public void setPosition(Vertex next){
		this.position= next; 
	}

	//returns whether the huner is armed or not
	public boolean getArmed(){
		return this.armed;
	}

	//sets whether the hunter is armed or not
	public void setArmed(boolean armed){
		this.armed=armed;
	}

	//returns whether the hunter is alive or not
	public boolean getAlive(){
		return this.alive;
	}

	//sets whether the hunter is alive or not
	public void setAlive(boolean alive){
		this.alive=alive;
	}

	//draws the hunter depending on whether it is alive, dead, or armed
	public void draw(Graphics g, int scale){
		g.setColor(Color.yellow);
		int xPos = (int)this.position.getX()*scale;
        int yPos = (int)this.position.getY()*scale;
        if (this.alive==false){
        	g.fillOval(xPos+scale/4, yPos+scale/4, scale/2, scale/2);
        	g.setColor(Color.black);
        	g.drawArc(xPos+3*scale/8, yPos+scale/2, scale/4, scale/8, 0, 180);
        	g.drawLine(xPos+scale/3+scale/16, yPos+3*scale/8, xPos+scale/3+scale/16+scale/12, yPos+3*scale/8+scale/12);
        	g.drawLine(xPos+5*scale/8-scale/16, yPos+3*scale/8, xPos+5*scale/8-scale/16+scale/12, yPos+3*scale/8+scale/12);
        	g.drawLine(xPos+scale/3+scale/16, yPos+3*scale/8+scale/12, xPos+scale/3+scale/16+scale/12, yPos+3*scale/8);
        	g.drawLine(xPos+5*scale/8-scale/16, yPos+3*scale/8+scale/12, xPos+5*scale/8-scale/16+scale/12, yPos+3*scale/8);
        }
        else{
        	g.fillOval(xPos+scale/4, yPos+scale/4, scale/2, scale/2);
        	g.setColor(Color.black);
        	g.drawArc(xPos+3*scale/8, yPos+scale/2, scale/4, scale/8, 180, 180);
        	g.fillOval(xPos+scale/3+scale/16, yPos+3*scale/8, scale/12, scale/12);
        	g.fillOval(xPos+5*scale/8-scale/16, yPos+3*scale/8, scale/12, scale/12);
        }
        if (this.armed==true){
        	g.setColor(Color.black);
        	g.fillOval(xPos+3*scale/4, yPos+3*scale/4, scale/8, scale/8);
         }

	}



}