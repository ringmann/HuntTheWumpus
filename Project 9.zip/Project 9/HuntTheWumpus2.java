/**
 * File: HuntTheWumpus2.java
 * Author: Rosie Ingmann
 * Date: 05/12/2021
 *CS231
 */ 
//This class represents an improved game of HuntTheWumpus

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.Graphics;
import java.awt.Dimension;
import java.awt.Color;
import java.awt.event.MouseEvent;
import java.awt.Point;
import java.util.Random;

import javax.imageio.ImageIO;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.event.MouseInputAdapter;

import java.util.*;


public class HuntTheWumpus2{

	private JFrame win;
    private LandscapePanel canvas;    
    private Landscape scape; 
    private int scale;

    JLabel field;

	private enum PlayState { PLAY, STOP }
    private PlayState state;

    private Graph graph;
    private Hunter hunter;
    private Wumpus wumpus;
    private Vertex pit;
    private Vertex v1  ;
    private Vertex v2 ;
    private Vertex v3 ;
    private Vertex v4 ;
    private Vertex v5 ;
    private Vertex v6 ;
    private Vertex v7 ;
    private Vertex v8 ;
    private Vertex v9 ;
    private Vertex v10 ;
    private Vertex v11 ;
    private Vertex v12  ;
    private Vertex v13  ;
    private Vertex v14 ;
    private Vertex v15  ;
    private Vertex v16  ;
    private Vertex v17 ;
    private Vertex v18  ;
    private Vertex v19 ;
    private Vertex v20  ;
    private Vertex v21  ;
    private Vertex v22 ;
    private Vertex v23 ;
    private Vertex v24 ;
    private Vertex v25 ;

    public HuntTheWumpus2(){
    	this.state = PlayState.PLAY; 
    	this.scale = 64;  
        this.scape = new Landscape(scale*10,scale*7);

        //initialized the graph and its vertices
        v1 = new Vertex( 0, 0 );
        v2 = new Vertex( 1, 0 );
         v3 = new Vertex( 2, 0 );
         v4 = new Vertex( 3, 0 );
         v5 = new Vertex( 4, 0 );
         v6 = new Vertex( 0, 1 );
         v7 = new Vertex( 1, 1 );
         v8 = new Vertex( 2, 1 );
         v9 = new Vertex( 3, 1 );
         v10 = new Vertex( 4, 1 );
         v11 = new Vertex( 0, 2 );
         v12 = new Vertex( 1, 2 );
         v13 = new Vertex( 2, 2 );
         v14 = new Vertex( 3, 2 );
         v15 = new Vertex( 4, 2 );
         v16 = new Vertex( 0, 3 );
         v17 = new Vertex( 1, 3 );
         v18 = new Vertex( 2, 3 );
         v19 = new Vertex( 3, 3 );
         v20 = new Vertex( 4, 3 );
         v21 = new Vertex( 0, 4 );
         v22 = new Vertex( 1, 4 );
         v23 = new Vertex( 2, 4 );
         v24 = new Vertex( 3, 4 );
         v25 = new Vertex( 4, 4 );
        ArrayList<Vertex> vertices= new ArrayList<Vertex>(Arrays.asList(v1 ,v2 ,v3 ,v4 ,v5 ,v6 ,v7 ,v8 ,v9 ,v10 ,v11 ,v12 ,v13 ,v14 ,v15, v16,
        	v17,v18, v19, v20, v21, v22, v23, v24, v25));
        for (int i=0; i< vertices.size(); i++){
        	//vertices.get(i).setVisible(true);
        	vertices.get(i).setCost(100);
        	this.scape.addBackgroundAgent( vertices.get(i) );
        }
        this.graph= new Graph(vertices);
        //connecting the vertices
        for (int row=0; row<5; row++){
        	for (int col=0; col<5; col++){
        		ArrayList<Vertex> list= new ArrayList<Vertex>();
        		list.add(this.graph.get(row+1, col));
        		list.add(this.graph.get(row-1, col));
        		list.add(this.graph.get(row, col+1));
        		list.add(this.graph.get(row, col-1));
        		for (int i=0; i<list.size(); i++){
        			if (list.get(i) != null){
        				this.graph.addBiEdge(this.graph.get(row, col), list.get(i));
        			}
        		}
        	}
        }
        //initializing a random location for the hunter, pit, and wumpus
        boolean foundPos = false;
        Random rand = new Random();
        while (foundPos==false){
            int huntPos = rand.nextInt(25);
            int wumpPos = rand.nextInt(25);
            int pitPos = rand.nextInt(25);
            Vertex huntVert = vertices.get(huntPos);
            Vertex wumpVert = vertices.get(wumpPos);
            Vertex pitVert = vertices.get(pitPos);
            HuntTheWumpus2.this.graph.shortestPath(wumpVert);
            if (huntVert.getCost()>=3 && pitVert.getCost()>=3){
                foundPos=true;
                this.wumpus=new Wumpus(wumpVert);
                this.hunter=new Hunter(huntVert);
                huntVert.setVisible(true);
                pitVert.setPit(true);
                this.pit=pitVert;
            }
        }
        this.scape.setHunter(this.hunter);
        this.scape.setWumpus(this.wumpus);

 
        this.win = new JFrame("Hunt The Wumpus Game");
        win.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE);
        this.canvas = new LandscapePanel( this.scape.getWidth(), this.scape.getHeight() );
        this.win.add( this.canvas, BorderLayout.CENTER );
        this.win.pack();

        this.field = new JLabel("Hunt The Wumpus");
        //this.fieldY = new JLabel("Y");
        JButton quit = new JButton("Quit");
        JButton replay = new JButton("Replay");
        JPanel panel = new JPanel( new FlowLayout(FlowLayout.RIGHT));
        panel.add( this.field );
        panel.add( quit );
        panel.add( replay);
        this.win.add( panel, BorderLayout.SOUTH);
        this.win.pack();

        Control control = new Control();
        this.win.addKeyListener(control);
        this.win.setFocusable(true);
        this.win.requestFocus();
        quit.addActionListener( control );
        replay.addActionListener( control);

        this.win.setVisible( true );


    }

    //control class which picks up on clicks and typing, does various tasks based on the action performed
    private class Control extends KeyAdapter implements ActionListener {

        //what happens if a key is typed
        public void keyTyped(KeyEvent e) {
            System.out.println( "Key Pressed: " + e.getKeyChar() );
            if( ("" + e.getKeyChar()).equalsIgnoreCase("q") ) {
                state = PlayState.STOP;
            }
            if( ("" + e.getKeyChar()).equalsIgnoreCase("w") ) {
            	Vertex above= HuntTheWumpus2.this.graph.get(HuntTheWumpus2.this.hunter.getPosition().getX(), HuntTheWumpus2.this.hunter.getPosition().getY()-1);
            	if (above!=null){
                    if (HuntTheWumpus2.this.hunter.getArmed()==true){
                        if (HuntTheWumpus2.this.wumpus.getPosition().equals(above)){
                            HuntTheWumpus2.this.wumpus.setAlive(false);
                            HuntTheWumpus2.this.scape.setDrawWumpus(true);
                            field.setText("Woohoo! You killed the wumpus!");
                        }
                        else{
                            HuntTheWumpus2.this.hunter.setAlive(false);
                            HuntTheWumpus2.this.scape.setDrawWumpus(true);
                            field.setText( "Miss! The wumpus kills you");
                        }
                    }
                    else{
                        HuntTheWumpus2.this.hunter.setPosition(above);
                        above.setVisible(true);
                        HuntTheWumpus2.this.graph.shortestPath(wumpus.getPosition());
                        if (above.equals(HuntTheWumpus2.this.pit)){
                            HuntTheWumpus2.this.scape.setDrawHunter(false);
                            field.setText("Oops, you fell into the pit!");
                        }
                    }
            	}
            }
            if( ("" + e.getKeyChar()).equalsIgnoreCase("s") ) {
            	//check if hunter has a neighbor above
            	Vertex below= HuntTheWumpus2.this.graph.get(HuntTheWumpus2.this.hunter.getPosition().getX(), HuntTheWumpus2.this.hunter.getPosition().getY()+1);
            	if (below!=null){
            		if (HuntTheWumpus2.this.hunter.getArmed()==true){
                        if (HuntTheWumpus2.this.wumpus.getPosition().equals(below)){
                            HuntTheWumpus2.this.wumpus.setAlive(false);
                            HuntTheWumpus2.this.scape.setDrawWumpus(true);
                            field.setText("Woohoo! You killed the wumpus!");
                        }
                        else{
                            HuntTheWumpus2.this.hunter.setAlive(false);
                            HuntTheWumpus2.this.scape.setDrawWumpus(true);
                            field.setText( "Miss! The wumpus kills you");
                        }
                    }
                    else{
                        HuntTheWumpus2.this.hunter.setPosition(below);
                        below.setVisible(true);
                        HuntTheWumpus2.this.graph.shortestPath(wumpus.getPosition());
                        if (below.equals(HuntTheWumpus2.this.pit)){
                            HuntTheWumpus2.this.scape.setDrawHunter(false);
                            field.setText("Oops, you fell into the pit!");
                        }
                    }
            	}
            }
            if( ("" + e.getKeyChar()).equalsIgnoreCase("d") ) {
            	//check if hunter has a neighbor above
            	Vertex right= HuntTheWumpus2.this.graph.get(HuntTheWumpus2.this.hunter.getPosition().getX()+1, HuntTheWumpus2.this.hunter.getPosition().getY());
            	if (right!=null){
            		if (HuntTheWumpus2.this.hunter.getArmed()==true){
                        if (HuntTheWumpus2.this.wumpus.getPosition().equals(right)){
                            HuntTheWumpus2.this.wumpus.setAlive(false);
                            HuntTheWumpus2.this.scape.setDrawWumpus(true);
                            field.setText("Woohoo! You killed the wumpus!");
                        }
                        else{
                            HuntTheWumpus2.this.hunter.setAlive(false);
                            HuntTheWumpus2.this.scape.setDrawWumpus(true);
                            field.setText( "Miss! The wumpus kills you");
                        }
                    }
                    else{
                        HuntTheWumpus2.this.hunter.setPosition(right);
                        right.setVisible(true);
                        HuntTheWumpus2.this.graph.shortestPath(wumpus.getPosition());
                        if (right.equals(HuntTheWumpus2.this.pit)){
                            HuntTheWumpus2.this.scape.setDrawHunter(false);
                            field.setText("Oops, you fell into the pit!");
                        }
                    }
            	}
            }
            if( ("" + e.getKeyChar()).equalsIgnoreCase("a") ) {
            	//check if hunter has a neighbor above
            	Vertex left= HuntTheWumpus2.this.graph.get(HuntTheWumpus2.this.hunter.getPosition().getX()-1, HuntTheWumpus2.this.hunter.getPosition().getY());
            	if (left!=null){
            	   if (HuntTheWumpus2.this.hunter.getArmed()==true){
                        if (HuntTheWumpus2.this.wumpus.getPosition().equals(left)){
                            HuntTheWumpus2.this.wumpus.setAlive(false);
                            HuntTheWumpus2.this.scape.setDrawWumpus(true);
                            field.setText("Woohoo! You killed the wumpus!");
                         }
                        else{
                            HuntTheWumpus2.this.hunter.setAlive(false);
                            HuntTheWumpus2.this.scape.setDrawWumpus(true);
                            field.setText( "Miss! The wumpus kills you");
                        }
                    }
                    else{
                        HuntTheWumpus2.this.hunter.setPosition(left);
                        left.setVisible(true);
                        HuntTheWumpus2.this.graph.shortestPath(wumpus.getPosition());
                        if (left.equals(HuntTheWumpus2.this.pit)){
                            HuntTheWumpus2.this.scape.setDrawHunter(false);
                            field.setText("Oops, you fell into the pit!");
                        }
                    }
            	}
            }
            if ( ("" + e.getKeyChar()).equalsIgnoreCase(" ") ){
            	if (HuntTheWumpus2.this.hunter.getArmed()==false){
                    HuntTheWumpus2.this.hunter.setArmed(true);
                    field.setText( "You are armed" );
                }
                else{
                    HuntTheWumpus2.this.hunter.setArmed(false); 
                    field.setText( "You are no longer armed" );
                }
             }
             if (HuntTheWumpus2.this.hunter.getPosition().equals(HuntTheWumpus2.this.wumpus.getPosition())){
                HuntTheWumpus2.this.hunter.setAlive(false);
                field.setText( "Oops! You've run into the wumpus" );
             }
        }

        //what happens if a button is clicked
        public void actionPerformed(ActionEvent event) {
            // If the Quit button was pressed
            if( event.getActionCommand().equalsIgnoreCase("Quit") ) {
		        System.out.println("Quit button clicked");
                state = PlayState.STOP;
            }
            if( event.getActionCommand().equalsIgnoreCase("Replay") ) {
                System.out.println("Replay button clicked");
                HuntTheWumpus2.this.hunter.setAlive(true);
                HuntTheWumpus2.this.wumpus.setAlive(true);
                HuntTheWumpus2.this.scape.setDrawWumpus(false);
                HuntTheWumpus2.this.scape.setDrawHunter(true);
                for (int i=0; i<25; i++){
                    HuntTheWumpus2.this.scape.getVertices().get(i).setVisible(false);
                    HuntTheWumpus2.this.scape.getVertices().get(i).setPit(false);
                }
                HuntTheWumpus2.this.hunter.setArmed(false);
                HuntTheWumpus2.this.win.requestFocus();
                boolean foundPos = false;
                Random rand = new Random();
                while (foundPos==false){
                    int huntPos = rand.nextInt(25);
                    int wumpPos = rand.nextInt(25);
                    int pitPos = rand.nextInt(25);
                    Vertex huntVert = HuntTheWumpus2.this.scape.getVertices().get(huntPos);
                    Vertex wumpVert = HuntTheWumpus2.this.scape.getVertices().get(wumpPos);
                    Vertex pitVert = HuntTheWumpus2.this.scape.getVertices().get(pitPos);
                    HuntTheWumpus2.this.graph.shortestPath(wumpVert);
                    if (huntVert.getCost()>=3 && pitVert.getCost()>=3){
                        foundPos=true;
                        HuntTheWumpus2.this.wumpus.setPosition(wumpVert);
                        HuntTheWumpus2.this.hunter.setPosition(huntVert);
                        huntVert.setVisible(true);
                        HuntTheWumpus2.this.pit=pitVert;
                        pitVert.setPit(true);
                    }
                }
                field.setText("Hunt The Wumpus");   
            }
        }
    }

    //landscape panel class
    private class LandscapePanel extends JPanel {
		
        /**
         * Creates the drawing canvas
         * @param height the height of the panel in pixels
         * @param width the width of the panel in pixels
         **/
        public LandscapePanel(int height, int width) {
            super();
            this.setPreferredSize( new Dimension( width, height ) );
            this.setBackground(Color.white);
        }

        /**
         * Method overridden from JComponent that is responsible for
         * drawing components on the screen.  The supplied Graphics
         * object is used to draw.
         * 
         * @param g		the Graphics object used for drawing
         */
        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            scape.draw( g, scale );
        }
    }  

    //repaints the landscape
    public void repaint() {
    	this.win.repaint();
    }

    //disposes of the window
    public void dispose() {
	    this.win.dispose();
    }

    //main method which plays the game
    public static void main(String[] args) throws InterruptedException  {
    	HuntTheWumpus2 w = new HuntTheWumpus2();
        while (w.state == PlayState.PLAY) {
            w.repaint();
            Thread.sleep(33);
        }
        System.out.println("Disposing window");
        w.dispose();
    }


}