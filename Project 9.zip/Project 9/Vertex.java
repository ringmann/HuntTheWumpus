/**
 * File: Vertex.java
 * Author: Rosie Ingmann
 * Date: 05/12/2021
 *CS231
 */	
//This class represents a Vertex in a game of HuntTheWumpus

import java.util.ArrayList;
import java.awt.Graphics;
import java.awt.Color;

public class Vertex implements Comparable<Vertex>{
	private ArrayList<Vertex> neighbors;
	private boolean visible;
	private int xPos;
	private int yPos;
	private double cost;
	private boolean marked;
	private Vertex parent;
	private boolean isPit;

	//constructor with input specifying whether vertex should be visible
	public Vertex(int x, int y, boolean visible){
		this.xPos=x;
		this.yPos=y;
		this.visible=visible;
		this.cost=0;
		this.marked=false;
		this.parent=null;
		this.neighbors=new ArrayList<Vertex>();
		this.isPit=false;
	}

	//constructor setting visible to false initially
	public Vertex(int x, int y){
		this.xPos=x;
		this.yPos=y;
		this.visible=false;
		this.cost=0;
		this.marked=false;
		this.parent=null;
		this.neighbors=new ArrayList<Vertex>();
		this.isPit=false;
	}

	//returns the list of the vertex's neighbors
	public ArrayList<Vertex> getNeighbors(){
		return this.neighbors;
	}

	//sets the neighbors of the vertex from a given arraylist
	public void setNeighbors(ArrayList<Vertex> neighbors){
		this.neighbors=neighbors;
	}

	//returns whether the vertex is visible
	public boolean getVisible(){
		return this.visible;
	}

	//sets the visibility of the vertex
	public void setVisible(boolean vis){
		this.visible=vis;
	}

	//returns the y position of the vertex
	public int getY(){
		return this.yPos;
	}

	//returns the x position of the vertex
	public int getX(){
		return this.xPos;
	}

	//sets the x and y positions of the vertex
	public void setPos(int x, int y){
		this.xPos=x;
		this.yPos=y;
	}

	//returns the cost of this vertex
	public double getCost(){
		return this.cost;
	}

	//sets the cost of this vertex
	public void setCost(double cost){
		this.cost=cost;
	}

	//returns whether vertex is marked or not
	public boolean getMarked(){
		return this.marked;
	}

	//sets whether the vertex is marked or not
	public void setMarked(boolean marked){
		this.marked=marked;
	}

	//returns the parent of the vertex
	public Vertex getParent(){
		return this.parent;
	}

	//sets the parent of the vertex
	public void setParent(Vertex parent){
		this.parent=parent;
	}

	//part of extension
	//returns whether the vertex is a pit of not 
	public boolean isAPit(){
		return this.isPit;
	}

	//sets whether the vertex is a pit or not
	public void setPit(boolean pit){
		this.isPit=pit;
	}

	//calculates the distance between this vertex and a given other vertex
	public double distance( Vertex other ){
		return Math.sqrt(Math.pow(other.getY()-this.getY(), 2)+Math.pow(other.getX()-this.getX(), 2));
	}

	//connects another vertex to this vertex (one way connection)
	public void connect(Vertex other){
		this.neighbors.add(other);
	}

	//returns the neighbor at a specified coordinate, or that there is not one
	public Vertex getNeighbor(int x, int y){
		for (int i=0; i<this.neighbors.size(); i++){
			Vertex neighbor= this.neighbors.get(i);
			if (neighbor.getX()==x && neighbor.getY()==y){
				return neighbor;
			}
		}
		return null;
	}

	//returns the number of neighbors that the vertex has
	public int numNeighbors(){
		return this.neighbors.size();
	}

	//string representation of the vertex, includes information about its number of neighbors, cost, and whether it is marked
	public String toString(){
		return " neighbors: " + this.numNeighbors() + " cost: " + this.cost + " marked: " + this.marked;
	}

	//compares the costs ofthis vertex and another vertex
	public int compareTo(Vertex other){
		return (int)(this.cost-other.getCost());

	}

	//draws the verex, changing its appearance based on its cost, whether it 
	//has a pit as a neighbor, or whether it is a pit (pit is part of an extra credit extension)
	public void draw(Graphics g, int scale) {
        if (!this.visible)
            return;
        int xpos = (int)this.getX()*scale;
        int ypos = (int)this.getY()*scale;
        int border = 2;
        int half = scale / 2;
        int eighth = scale / 8;
        int sixteenth = scale / 16;
        
        // draw rectangle for the walls of the room
        if (this.getCost() <= 2){
            // wumpus is nearby
            g.setColor(Color.red);
 		}
        else{
        	g.setColor(Color.black);
        	for (int i=0; i<this.neighbors.size(); i++){
        		if (this.neighbors.get(i).isAPit()==true){
        			g.setColor(Color.blue);
        		}
        	}
            // wumpus is not nearby
        }
        if (this.isPit==true){
        	g.fillRect(xpos + border, ypos + border, scale - 2*border, scale - 2 * border);
        }
        else{
        	g.drawRect(xpos + border, ypos + border, scale - 2*border, scale - 2 * border);
        }
        
        // draw doorways as boxes
        g.setColor(Color.black);
        if (this.getNeighbor( this.getX(), this.getY()-1 ) != null ){
            g.fillRect(xpos + half - sixteenth, ypos, eighth, eighth + sixteenth);
        }
        if (this.getNeighbor( this.getX(), this.getY()+1 ) != null){
            g.fillRect(xpos + half - sixteenth, ypos + scale - (eighth + sixteenth), 
                       eighth, eighth + sixteenth);
        }
        if (this.getNeighbor( this.getX()-1, this.getY() )!= null){
            g.fillRect(xpos, ypos + half - sixteenth, eighth + sixteenth, eighth);
        }
        if (this.getNeighbor( this.getX()+1, this.getY() )!= null){
            g.fillRect(xpos + scale - (eighth + sixteenth), ypos + half - sixteenth, 
                       eighth + sixteenth, eighth);
        }
    }

    //static method, checks if two vertices are the same position
	public static boolean matchPosition( Vertex a, Vertex b ){
		if (a.getX()==b.getX() && a.getY()==b.getY()){
			return true;
		}
		return false;
	}

	//main method for testing
	public static void main(String[] args) {
		Vertex v1= new Vertex(5,5, false);
		Vertex v2= new Vertex(6,1, false);
		Vertex v3= new Vertex(1,1, false);
		ArrayList<Vertex> neighbors1= new ArrayList<Vertex>();
		neighbors1.add(v2);
		neighbors1.add(v3);
		ArrayList<Vertex> neighbors2= new ArrayList<Vertex>();
		neighbors2.add(v1);
		ArrayList<Vertex> neighbors3= new ArrayList<Vertex>();
		neighbors3.add(v1);
		v1.setNeighbors(neighbors1);
		v2.setNeighbors(neighbors2);
		v3.setNeighbors(neighbors3);
		//System.out.println(v1.getNeighbors());
		//System.out.println(v2.getNeighbors());
		//System.out.println(v3.getNeighbors());
		v1.setVisible(true);
		//System.out.println(v1.getVisible());
		//System.out.println(v2.getVisible());
		//System.out.println(v1.getX());
		//System.out.println(v1.getY());
		v1.setPos(4,3);
		//System.out.println(v1.getX());
		//System.out.println(v1.getY());
		//System.out.println(v1.getCost());
		v1.setCost(6);
		//System.out.println(v1.getCost());
		//System.out.println(v1.getMarked());
		v1.setMarked(true);
		//System.out.println(v1.getMarked());
		//System.out.println(v1.getParent());
		v1.setParent(v2);
		//System.out.println(v1.getParent());
		//System.out.println(v1.distance(v2));
		//System.out.println(v2.distance(v1));
		//System.out.println(v1.getNeighbor(1,1));
		//System.out.println(v1.getNeighbor(1,2));
		//System.out.println(v1.numNeighbors());
		v1.connect(v2);
		//System.out.println(v1.numNeighbors());
		//System.out.println(v2.numNeighbors());
		//System.out.println(v1.compareTo(v2));
		//System.out.println(v2.compareTo(v3));
		System.out.println(matchPosition(v1, v3));
	}












}