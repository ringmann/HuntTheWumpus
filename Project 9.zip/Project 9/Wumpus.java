/**
 * File: Wumpus.java
 * Author: Rosie Ingmann
 * Date: 05/12/2021
 *CS231
 */	
//This class represents a Wumpus in a game of HuntTheWumpus

import java.awt.Graphics;
import java.awt.Color;

public class Wumpus{

	private Vertex position;
	private boolean alive;

	//initializes the wumpus to be alive
	public Wumpus(Vertex pos){
		this.position=pos;
		this.alive=true;
	}

	//gets the wumpus's position vertex
	public Vertex getPosition(){
		return this.position;
	}

	//sets the wumpus's position vertex
	public void setPosition(Vertex next){
		this.position= next; 
	}

	//returns whether the wumpus is alive or not
	public boolean getAlive(){
		return this.alive;
	}

	//sets whether the wumpus is alive or not
	public void setAlive(boolean alive){
		this.alive=alive;
	}
	
	//draws the wumpus based on whether it is alive or not
	public void draw(Graphics g, int scale){	
		int xPos = (int)this.position.getX()*scale;
        int yPos = (int)this.position.getY()*scale;
		if (this.alive==true){
			g.setColor(Color.orange);
			g.fillOval(xPos+scale/4, yPos+scale/4, scale/2, scale/2);
			g.setColor(Color.black);
        	g.drawArc(xPos+3*scale/8, yPos+scale/2, scale/4, scale/8, 180, 180);
        	g.fillOval(xPos+scale/3+scale/16, yPos+3*scale/8, scale/12, scale/12);
        	g.fillOval(xPos+5*scale/8-scale/16, yPos+3*scale/8, scale/12, scale/12);
		}
		else{
			g.setColor(Color.red);
			g.fillOval(xPos+scale/4, yPos+scale/4, scale/2, scale/2);
			g.setColor(Color.black);
        	g.drawArc(xPos+3*scale/8, yPos+scale/2, scale/4, scale/8, 0, 180);
        	g.drawLine(xPos+scale/3+scale/16, yPos+3*scale/8, xPos+scale/3+scale/16+scale/12, yPos+3*scale/8+scale/12);
        	g.drawLine(xPos+5*scale/8-scale/16, yPos+3*scale/8, xPos+5*scale/8-scale/16+scale/12, yPos+3*scale/8+scale/12);
        	g.drawLine(xPos+scale/3+scale/16, yPos+3*scale/8+scale/12, xPos+scale/3+scale/16+scale/12, yPos+3*scale/8);
        	g.drawLine(xPos+5*scale/8-scale/16, yPos+3*scale/8+scale/12, xPos+5*scale/8-scale/16+scale/12, yPos+3*scale/8);
		}

	}



}