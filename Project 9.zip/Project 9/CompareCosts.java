
/**
 * File: CompareCosts.java
 * Author: Rosie Ingmann
 * Date: 5/1/2021
 *CS231
 */ 
//This class implements a comparator that compares vertices by their costs



import java.util.*;

public class CompareCosts implements Comparator<Vertex>{

	//compares two vertices by their costs
	//if values are equal, will return 0. if a>b, returns a positive number, and if a<b, returns a negative number
	public int compare(Vertex a, Vertex b){
		return (int)(a.getCost()-b.getCost());

	}
}